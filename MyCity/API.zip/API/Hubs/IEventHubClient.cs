﻿namespace API.Hubs;
public interface IEventHubClient
{
    Task GetEventHubName();
}
