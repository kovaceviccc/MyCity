﻿using API.Extensions;
using API.Hubs;
using API.Models.DTOs;
using Entities.Repository.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using System.Security.Claims;

namespace API.Hubs;

[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
public class EventHub : Hub
{
	private readonly IEventRepository _eventRepository;
    private readonly IAuthRepository _authRepository;

    public async Task EventRecived(EventDto eventDto)
    {
		try
		{
			string userId = Context.GetHttpContext()!.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value!;

			var user = await _authRepository.FindByEmailAsync(userId);

			if (user is null) return;

			var eventToAdd = Mapper.Map(eventDto, user);

			var resut = await _eventRepository.AddEvent(eventToAdd);



			if (resut)
			{
                await Clients.All.SendAsync("EventRecived", new EventResponseDto
                {
                    Id = "12345",
                    PublisherId = user.Id,
                    Title = eventToAdd.Title,
                    Description = eventToAdd.Description,
                    Latitude = eventToAdd.Latitude,
                    Longitude = eventToAdd.Longitude,
                    EventType = eventToAdd.EventType
                });
            }
        }
		catch (Exception ex)
		{
			string message = ex.Message;
			string inner = ex.InnerException!.Message;

		}
    }

    [HttpPost]
    public async Task LikeEvent(string eventId)
    {

        try
        {
            string userId = Context.GetHttpContext()!.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value!;
            if (eventId is null || userId is null) return;
            var result = await _eventRepository.LikeEvent(eventId, userId);

            if(result)
            {
                await Clients.All.SendAsync("EventChanged", eventId);
            }

        }
        catch (Exception ex)
        {
            string error = ex.Message;
            string inner = ex.InnerException!.Message;
            //log error;
        }
    }

    public EventHub(IEventRepository eventRepository,
					IAuthRepository authRepository)
    {
		_eventRepository = eventRepository;
		_authRepository = authRepository;
    }
}
