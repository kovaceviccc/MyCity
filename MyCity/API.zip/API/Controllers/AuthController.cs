﻿using API.Extensions;
using API.Models;
using API.Models.DTOs;
using Entities.DbSet;
using Entities.Domain.Enums;
using Entities.Repository.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;

namespace API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly IAuthRepository _authRepository;
    private readonly IUserRepository _userRepository;

    public AuthController(
        IAuthRepository authRepository,
        IUserRepository userRepository)
    {
        _authRepository = authRepository;
        _userRepository = userRepository;
    }

    [HttpPost]
    [Route("Register")]
    public async Task<IActionResult> Register([FromBody] UserRegistrationRequestDto request)
    {
        if(!ModelState.IsValid)
        {
            return BadRequest("Invalid payload");
        }

        var user = await _authRepository.FindByEmailAsync(request.Email);

        if(user is not  null)
        {
            return StatusCode(StatusCodes.Status400BadRequest,new AuthResult
            {
                Result = false,
                Errors = new List<string>()
                {
                    "User with this email already exists"
                }
            });
        }

        User newUser = request.Map();

        var isCreated = await _authRepository.RegisterUser(newUser, request.Password);

        if(!isCreated)
        {
            return StatusCode(StatusCodes.Status400BadRequest,"Failed to create user");
        }

        (string jwtToken, string refreshToken) = await _authRepository.GenerateTokens(newUser);

        if(jwtToken is null || refreshToken is null) 
        {
            return StatusCode(StatusCodes.Status400BadRequest, "Failed to create user");
        }

        return StatusCode(StatusCodes.Status201Created,new AuthResult
        {
            Result = true,
            Token = jwtToken,
            RefreshToken = refreshToken
        });
    }

    [HttpPost]
    [Route("AddRoles")]
    public async Task<IActionResult> AddRoles(string id)
    {

        await _authRepository.CreateRole(RolesEnum.User.ToString());
        await _authRepository.CreateRole(RolesEnum.Admin.ToString());
        await _authRepository.CreateRole(RolesEnum.AuthorizedPersonel.ToString());

        var res = await _userRepository.AddToRoles(id);

        if (!res) return StatusCode(StatusCodes.Status400BadRequest, "Failed");

        return StatusCode(StatusCodes.Status201Created, "Success");
    }

    [HttpPost]
    [Route("CreateRole")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "Admin")]
    public async Task<IActionResult> CreateRole(string roleName)
    {
        var result = await _authRepository.CreateRole(roleName);

        if(result is true)
        {
            return Ok($"Role {roleName} successfully added");
        }
        else
        {
            return StatusCode(StatusCodes.Status500InternalServerError, "Failed to add role");
        }

    }

    [HttpPost]
    [Route("Login")]
    public async Task<IActionResult> Login([FromBody]UserLoginRequestDto request)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(new AuthResult
            {
                Errors = new List<string>
                {
                    "Invalid payload"
                },
                Result = false
            });
        }

        var existingUser = await _authRepository.FindByEmailAsync(request.Email);

        if (existingUser is null)
        {
            return StatusCode(StatusCodes.Status400BadRequest,new AuthResult
            {
                Result = false,
                Errors = new List<string>{
                    "Invalid payload"
                },
            });
        }

        var isCorrect = await _authRepository.ValidatePassword(existingUser, request.Password);

        if (!isCorrect)
        {
            return BadRequest(new AuthResult
            {
                Result = false,
                Errors = new List<string> { "Invalid credentials" }
            });
        }

        (string jwtToken, string refreshToken) = await _authRepository.GenerateTokens(existingUser);

        return Ok(new AuthResult()
        {
            Result = true,
            Token = jwtToken,
            RefreshToken = refreshToken
        });
    }

    [HttpPost]
    [Route("ChangePassword")]
    //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public async Task<IActionResult> ChangePassword([FromBody]ChangePasswordRequestDto request)
    {
        if (!ModelState.IsValid) 
        {
            return StatusCode(StatusCodes.Status400BadRequest, "Invalid payload");
        }

       // string authHeader = HttpContext.Request.Headers["Authorization"]!;
        //string jwtToken = authHeader.Replace("Bearer ", "");
        string userId = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value!;

        var user = await _authRepository.FindByEmailAsync(userId);

        if (user is null) return StatusCode(StatusCodes.Status401Unauthorized);

        var success = await _userRepository.ChangePassword(user, request.OldPassword, request.NewPassword);

        if(!success)
        {
            return StatusCode(StatusCodes.Status400BadRequest, "Invalid password");
        }

        return StatusCode(StatusCodes.Status202Accepted);
    }

    [HttpGet]
    [Route("GetUserInfo")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "User")]
    public async Task<IActionResult> GetUserInfo()
    {
        //string authHeader = HttpContext.Request.Headers["Authorization"]!;
        //string jwtToken = authHeader.Replace("Bearer ", "");
        string userId = HttpContext.User.Claims.FirstOrDefault(c=> c.Type == ClaimTypes.NameIdentifier)?.Value!;

        var user = await _authRepository.FindByEmailAsync(userId);

        if(user is null)
        {
            return StatusCode(StatusCodes.Status400BadRequest);
        }

        return StatusCode(StatusCodes.Status202Accepted,new BasicUserInfoDto
        {
            FirstName = user.FirstName,
            LastName = user.LastName,
            UserName = user.DisplayName,
            Email = user.Email!
        });

    }

    [HttpPost]
    [Route("RefreshToken")]
    public async Task<IActionResult> RefreshToken([FromBody]TokenRequest tokenRequest)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(new AuthResult
            {
                Errors = new List<string> { "Invalil parameters" },
                Result = false
            });
        }

        var validated = await _authRepository.ValidateTokens(tokenRequest.Token, tokenRequest.RefreshToken);

        if(!validated)
        {
            return Ok(new AuthResult
            {
                Errors = new List<string>
                {
                    "Invalid tokens"
                },
                Result = false
            });
        }

        (string jwtToken, string refreshToken) = await _authRepository.GenerateTokens(tokenRequest.RefreshToken);
         
        if (jwtToken.IsNullOrEmpty() || refreshToken.IsNullOrEmpty())
        {
            return StatusCode(StatusCodes.Status400BadRequest,new AuthResult
            {
                Errors = new List<string>
                {
                    "Invalid tokens"
                },
                Result = false
            });
        }

        return StatusCode(StatusCodes.Status201Created,new AuthResult
        {
            Token = jwtToken,
            RefreshToken = refreshToken,
        });
    }

    //private async Task<AuthResult> VerifyAndGenerateTokens(TokenRequest tokenRequest)
    //{

    //    if(!ModelState.IsValid)
    //    {
    //        return new AuthResult
    //        {
    //            Errors = new List<string>
    //            {
    //                "Model state is invalid"
    //            }
    //        };
    //    }

    //    var jwtTokenHandler = new JwtSecurityTokenHandler();
    //    try
    //    {
    //        //_tokenValidationParameters.ValidateLifetime = false;
    //        var tokenInVerification = jwtTokenHandler.ValidateToken(tokenRequest.Token, _tokenValidationParameters, out var validatedToken);

    //        if (validatedToken is JwtSecurityToken jwtSecurityToken)
    //        {
    //            var result = jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase);

    //            if (result == false)
    //            {
    //                return new AuthResult
    //                {
    //                    Errors = new List<string> { "Invalid tokens" }
    //                };
    //            }
    //        }

    //        if(tokenInVerification is null)
    //        {
    //            return new AuthResult
    //            {
    //                Errors = new List<string>
    //                {
    //                    "Invalid tokens"
    //                },
    //                Result = false
    //            };
    //        }

    //        var utxExpieryDate = long.Parse(tokenInVerification.Claims?.FirstOrDefault(x => x?.Type == JwtRegisteredClaimNames.Exp)?.Value!);

    //        var expiryDate = UnixTimeStampToDateTime(utxExpieryDate);

    //        if(expiryDate > DateTime.Now)
    //        {
    //            return new AuthResult
    //            {
    //                Result = false,
    //                Errors = new List<string>
    //                {
    //                    "Token expired"
    //                }
    //            };
    //        }

    //        var storedToken = await _context.RefreshTokens.FirstOrDefaultAsync(x => x.Token.Equals(tokenRequest.RefreshToken));

    //        if(storedToken is null)
    //        {
    //            return new AuthResult
    //            {
    //                Result = false,
    //                Errors = new List<string>
    //                {
    //                    "Invalid tokens"
    //                }
    //            };

    //        }

    //        if(storedToken.IsUsed == true)
    //        {
    //            return new AuthResult
    //            {
    //                Result = false,
    //                Errors = new List<string>
    //                {
    //                    "Invalid tokens"
    //                }
    //            };
    //        }

    //        if(storedToken.IsRevoked == true) 
    //        {
    //            return new AuthResult
    //            {
    //                Result = false,
    //                Errors = new List<string>
    //                {
    //                    "Invalid tokens"
    //                }
    //            };
    //        }

    //        var jti = tokenInVerification.Claims?.FirstOrDefault(x => x.Type == JwtRegisteredClaimNames.Jti)?.Value;

    //        if(storedToken.JwtId != jti)
    //        {
    //            return new AuthResult
    //            {
    //                Result = false,
    //                Errors = new List<string>
    //                {
    //                    "Invalid tokens"
    //                }
    //            };
    //        }

    //        if(storedToken.ExpireDate < DateTime.UtcNow)
    //        {
    //            return new AuthResult
    //            {
    //                Result = false,
    //                Errors = new List<string>
    //                {
    //                    "Tokens inspired"
    //                }
    //            };
    //        }

    //        storedToken.IsUsed = true;
    //        _context.RefreshTokens.Update(storedToken);
    //        await _context.SaveChangesAsync();

    //        var user = await _userManager.FindByIdAsync(storedToken.UserId);

    //        if(user is null)
    //        {
    //            return new AuthResult
    //            {
    //                Errors = new List<string>
    //                {
    //                    "Invalid tokens"
    //                },
    //                Result = false
                    
    //            };
    //        }

    //        (string jwtToken, string refreshToken) = await GenerateTokens(user);

    //        return new AuthResult
    //        {
    //            Result = true,
    //            RefreshToken = refreshToken,
    //            Token = jwtToken,
    //        };

    //    }
    //    catch (Exception)
    //    {
    //        return new AuthResult
    //        {
    //            Errors = new List<string>
    //                {
    //                    "Server error"
    //                },
    //            Result = false

    //        };

    //    }
    //}

    //private DateTime UnixTimeStampToDateTime(long unixTimeStamp)
    //{
    //    var dateTimeVal = new DateTime(1970, 1, 1, 0, 0, 0,0, DateTimeKind.Utc);
    //    dateTimeVal = dateTimeVal.AddSeconds(unixTimeStamp).ToUniversalTime();
    //    return dateTimeVal;
    //}

    //private async Task<(string, string)> GenerateTokens(User user)
    //{
    //    var jwtTokenHandler = new JwtSecurityTokenHandler();

    //    var key = Encoding.UTF8.GetBytes(_configuration.GetSection("JwtConfig:Secret").Value!);

    //    var roles = await _userManager.GetRolesAsync(user);

    //    var claims =  await GetAllValidClaims(user);

    //    var tokenDecriptor = new SecurityTokenDescriptor
    //    {
    //        Subject = new ClaimsIdentity(claims),
    //        Expires = DateTime.UtcNow.Add(TimeSpan.Parse(_configuration.GetSection("JwtConfig:ExpiryTimeFrame").Value!)),
    //        SigningCredentials = new(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256)
    //    };

    //    var token = jwtTokenHandler.CreateToken(tokenDecriptor);
    //    var jwtToken = jwtTokenHandler.WriteToken(token);


    //    var refreshToken = new RefreshToken
    //    {
    //        JwtId = token.Id,
    //        Token = GenerateRefreshToken(),
    //        AddedDate = DateTime.UtcNow,
    //        ExpireDate = DateTime.UtcNow.AddMonths(6),
    //        UserId = user.Id,
    //    };
    //    user.RefreshTokens.Add(refreshToken);
    //    await _context.RefreshTokens.AddAsync(refreshToken);
    //    await _context.SaveChangesAsync();

    //    return (jwtToken, refreshToken.Token);
    //}

    //get all valid claims for the user 
    //private async Task<List<Claim>> GetAllValidClaims(User user)
    //{
    //    var claims = new List<Claim>
    //    {
    //        new Claim("Id", user.Id),
    //        new Claim(JwtRegisteredClaimNames.Sub, user.Email!),
    //        new Claim(JwtRegisteredClaimNames.Email, user.Email!),
    //        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
    //        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString())

    //    };

    //    //getting user claims
    //    var userClaims = await _userManager.GetClaimsAsync(user);
    //    claims.AddRange(userClaims);

    //    //get user roles and add it to the claims
    //    var userRoles = await _userManager.GetRolesAsync(user);

    //    foreach(var userRole in userRoles)
    //    {
           
    //        var role = await _roleManager.FindByNameAsync(userRole);


    //        if(role is not null)
    //        {
    //            claims.Add(new Claim(ClaimTypes.Role, userRole));
    //            var roleClaims = await _roleManager.GetClaimsAsync(role);
    //            foreach(var roleClaim in roleClaims)
    //            {
    //                claims.Add(roleClaim);
    //            }
    //        }
    //    }
    //    return claims;
    //}

    //private string GenerateRefreshToken()
    //{
    //    var randomNumber = new byte[64];
    //    using var rng = RandomNumberGenerator.Create();
    //    rng.GetBytes(randomNumber);
    //    return Convert.ToBase64String(randomNumber);
    //}
}
