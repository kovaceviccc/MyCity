﻿namespace Entities.Domain.Enums;

public enum RolesEnum
{
    Admin,
    User,
    AuthorizedPersonel

}
