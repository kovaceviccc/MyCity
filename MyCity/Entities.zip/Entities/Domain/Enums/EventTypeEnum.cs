﻿namespace Entities.Domain.Enums;

public enum EventTypeEnum
{
    CarCrash,
    Fire,
    Flood,
    Earthquake,
    Party,
    PublicEvent
}